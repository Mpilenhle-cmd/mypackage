#mypackage
This library is a rundown to publishing python packages

#How to install
the software installation procedures only requires download and run with a double click for installation